<?php

$email = "johnfernadez@yopmail.com.com"; // PUT UR FUCKING E-MAIL BRO

?>